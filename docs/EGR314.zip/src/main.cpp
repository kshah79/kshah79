#include <HardwareSerial.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <XPT2046_Touchscreen.h>

// --- UART Setup ---
HardwareSerial SerialFromF1(1);
HardwareSerial SerialToF2(2);

// --- TFT Pins ---
#define TFT_CS   15
#define TFT_DC   2
#define TFT_RST  4

// --- Touchscreen Pins ---
#define TOUCH_CS 21
#define TIRQ     -1

// --- Touch Calibration ---
#define TS_MINX  200
#define TS_MAXX  3800
#define TS_MINY  300
#define TS_MAXY  3700

// --- Display and Touch ---
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);
XPT2046_Touchscreen ts(TOUCH_CS, TIRQ);

// --- Font Size State ---
int fontSize = 2;
const int minSize = 1;
const int maxSize = 5;

// --- Message Buffer ---
char msgBuffer[9];

// --- Function Prototypes ---
bool isValidMessage(const char* msg);
String interpretMotorCommand(const char* msg);
void displayStatus(const String& status);
void drawButtons();

void setup() {
  Serial.begin(115200);
  SerialFromF1.begin(9600, SERIAL_8N1, 16, 17); // UART1 RX, TX
  SerialToF2.begin(9600, SERIAL_8N1, 26, 25);   // UART2 TX, RX

  tft.begin();
  ts.begin();
  ts.setRotation(1);
  tft.setRotation(1);

  tft.fillScreen(ILI9341_BLACK);
  drawButtons();

  tft.setTextColor(ILI9341_GREEN);
  tft.setTextSize(2);
  tft.setCursor(0, 0);
  tft.println("Motor Status:");
}

void loop() {
  // 1. Touch Input
  if (ts.touched()) {
    TS_Point p = ts.getPoint();
    int x = map(p.x, TS_MINX, TS_MAXX, 0, 320);
    int y = map(p.y, TS_MINY, TS_MAXY, 0, 240);

    bool changed = false;

    if (x > 20 && x < 120 && y > 180 && y < 230 && fontSize > minSize) {
      fontSize--;
      changed = true;
    } else if (x > 200 && x < 300 && y > 180 && y < 230 && fontSize < maxSize) {
      fontSize++;
      changed = true;
    }

    if (changed) {
      displayStatus("Font size: " + String(fontSize));
    }

    while (ts.touched()) delay(5);
  }

  // 2. UART Message Parsing
  while (SerialFromF1.available()) {
    char c = SerialFromF1.read();

    // Shift buffer left
    for (int i = 0; i < 7; i++) {
      msgBuffer[i] = msgBuffer[i + 1];
    }
    msgBuffer[7] = c;
    msgBuffer[8] = '\0';

    if (isValidMessage(msgBuffer)) {
      // Handle FSET messages by forwarding only
      if (strncmp(msgBuffer, "FSET", 4) == 0) {
        for (int i = 0; i < 8; i++) {
          SerialToF2.write(msgBuffer[i]);
        }
        Serial.println("📤 Forwarded FSET message");
        continue; // Skip further processing
      }

      // Handle messages relevant to us
      String status = interpretMotorCommand(msgBuffer);
      if (status != "") {
        displayStatus(status);

        // Forward original message
        for (int i = 0; i < 8; i++) {
          SerialToF2.write(msgBuffer[i]);
        }

        // Additional logic
        if (strncmp(msgBuffer, "FSSK01FS", 8) == 0) {
          SerialToF2.write("FSST01FS", 8);
        } else if (strncmp(msgBuffer, "FSSK03FS", 8) == 0) {
          SerialToF2.write("FSST02FS", 8);
        }
      }
    }
  }
}

void drawButtons() {
  // A- Button
  tft.fillRect(20, 180, 100, 50, ILI9341_RED);
  tft.drawRect(20, 180, 100, 50, ILI9341_WHITE);
  tft.setCursor(45, 195);
  tft.setTextColor(ILI9341_BLACK);
  tft.setTextSize(2);
  tft.print("A-");

  // A+ Button
  tft.fillRect(200, 180, 100, 50, ILI9341_GREEN);
  tft.drawRect(200, 180, 100, 50, ILI9341_WHITE);
  tft.setCursor(225, 195);
  tft.setTextColor(ILI9341_BLACK);
  tft.setTextSize(2);
  tft.print("A+");
}

void displayStatus(const String& status) {
  Serial.print("📟 Displaying: ");
  Serial.println(status);
  tft.fillRect(0, 40, 320, 60, ILI9341_BLACK);
  tft.setCursor(10, 60);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setTextSize(fontSize);
  tft.println(status);
}

bool isValidMessage(const char* msg) {
  return msg[0] == 'F' && msg[1] == 'S' && msg[6] == 'F' && msg[7] == 'S';
}

String interpretMotorCommand(const char* msg) {
  if (strncmp(msg, "FSSK01FS", 8) == 0) return "Motor OFF";
  if (strncmp(msg, "FSSK02FS", 8) == 0) return "Motor ONN";
  if (strncmp(msg, "FSSK03FS", 8) == 0) return "Motor REVERSE";
  if (strncmp(msg, "FSTS02FS", 8) == 0) return "Kevin";
  if (strncmp(msg, "FSTS01FS", 8) == 0) return "Sanjit";
  if (strncmp(msg, "FSEK", 4) == 0) {
    char tempStr[3] = { msg[4], msg[5], '\0' };
    int temperature = atoi(tempStr);
    return "Temperature: " + String(temperature) + "°C";
  }
  if (strncmp(msg, "FSSS", 4) == 0) return "";  // ignore loopback
  return "";
}
